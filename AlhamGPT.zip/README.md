# AlhamAIReply

Android Kotlin project with notification-based chat auto-replies and an experimental call assistant.

## Build on GitHub
1. Create a new GitHub repository.
2. Upload the **contents of this folder** to the repository root (the `.github` folder must also be at the root).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build AlhamAIReply APK** (or push a commit to trigger it).
5. Open the completed workflow run and download `AlhamAIReply-debug-apk` under Artifacts.

The generated APK is a debug build. It is not a Play Store release and is not signed with a private release key.

## Important cellular-call limitations
Android does not provide ordinary third-party apps with public APIs to capture the remote party's cellular-call downlink or inject arbitrary generated audio into the cellular-call microphone uplink. `AudioRecord` with `MIC` records the app-accessible microphone signal; it is not a guaranteed two-way phone-call recording. TTS through the loudspeaker is not guaranteed to be heard by the other caller because echo cancellation and telephony routing can suppress it. Do not claim otherwise or try hidden/private APIs.

The call assistant is experimental and device-dependent. The recording preference is off by default. Obtain consent from all required parties and follow local recording laws before enabling recording.

## Permissions
The app requests microphone, phone state, answer-call, notification, and foreground-service permissions for its advertised features. Android/OEM restrictions may prevent some features from operating.
