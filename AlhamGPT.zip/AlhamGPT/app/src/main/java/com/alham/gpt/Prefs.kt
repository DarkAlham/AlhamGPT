package com.alham.gpt

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** All user settings, stored in SharedPreferences. */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("alham", Context.MODE_PRIVATE)

    private fun s(k: String, d: String): String = sp.getString(k, d) ?: d
    private fun b(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    private fun i(k: String, d: Int): Int = sp.getInt(k, d)

    var apiKey: String
        get() = s("apiKey", "")
        set(v) { sp.edit().putString("apiKey", v).apply() }

    var model: String
        get() = s("model", "gemini-2.5-flash")
        set(v) { sp.edit().putString("model", v).apply() }

    var ownerName: String
        get() = s("ownerName", "Alham")
        set(v) { sp.edit().putString("ownerName", v).apply() }

    var persona: String
        get() = s(
            "persona",
            "Be polite, friendly and brief. Say that the owner is busy right now and will reply later. " +
                "If the person has something important, ask for their name and a short message."
        )
        set(v) { sp.edit().putString("persona", v).apply() }

    var packages: String
        get() = s("packages", "com.whatsapp,com.whatsapp.w4b")
        set(v) { sp.edit().putString("packages", v).apply() }

    var replyPrefix: String
        get() = s("replyPrefix", "🤖 ")
        set(v) { sp.edit().putString("replyPrefix", v).apply() }

    var autoReply: Boolean
        get() = b("autoReply", true)
        set(v) { sp.edit().putBoolean("autoReply", v).apply() }

    var replyGroups: Boolean
        get() = b("replyGroups", false)
        set(v) { sp.edit().putBoolean("replyGroups", v).apply() }

    var replyDelaySec: Int
        get() = i("replyDelaySec", 2)
        set(v) { sp.edit().putInt("replyDelaySec", v).apply() }

    var callAnswer: Boolean
        get() = b("callAnswer", false)
        set(v) { sp.edit().putBoolean("callAnswer", v).apply() }

    var ringDelaySec: Int
        get() = i("ringDelaySec", 10)
        set(v) { sp.edit().putInt("ringDelaySec", v).apply() }

    var recordCalls: Boolean
        get() = b("recordCalls", true)
        set(v) { sp.edit().putBoolean("recordCalls", v).apply() }

    var greeting: String
        get() = s(
            "greeting",
            "Hello, this is AlhamGPT, an AI assistant. The owner is not available right now, " +
                "and this call may be recorded. How can I help you?"
        )
        set(v) { sp.edit().putString("greeting", v).apply() }

    var greetingLang: String
        get() = s("greetingLang", "en-IN")
        set(v) { sp.edit().putString("greetingLang", v).apply() }
}

/** Where call recordings and transcripts are saved. */
object Storage {
    fun dir(ctx: Context): File {
        val base = ctx.getExternalFilesDir("recordings") ?: File(ctx.filesDir, "recordings")
        base.mkdirs()
        return base
    }
}

/** Tiny on-device log so problems can be seen without a computer. */
object AppLog {
    private const val MAX_LINES = 80

    @Synchronized
    fun add(ctx: Context, msg: String) {
        Log.d("AlhamGPT", msg)
        try {
            val f = File(ctx.filesDir, "log.txt")
            val lines = if (f.exists()) f.readLines().toMutableList() else mutableListOf()
            val stamp = SimpleDateFormat("dd MMM HH:mm:ss", Locale.US).format(Date())
            lines.add(stamp + "  " + msg.replace('\n', ' '))
            while (lines.size > MAX_LINES) lines.removeAt(0)
            f.writeText(lines.joinToString("\n"))
        } catch (e: Exception) {
            Log.e("AlhamGPT", "log failed", e)
        }
    }

    @Synchronized
    fun read(ctx: Context): String {
        return try {
            val f = File(ctx.filesDir, "log.txt")
            if (f.exists()) f.readText().ifBlank { "(log is empty)" } else "(log is empty)"
        } catch (e: Exception) {
            "(could not read log)"
        }
    }
}
