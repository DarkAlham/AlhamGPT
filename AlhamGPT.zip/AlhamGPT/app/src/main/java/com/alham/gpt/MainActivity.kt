package com.alham.gpt

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var btnService: Button

    private lateinit var etKey: EditText
    private lateinit var etModel: EditText
    private lateinit var etOwner: EditText
    private lateinit var etPersona: EditText
    private lateinit var etPackages: EditText
    private lateinit var etPrefix: EditText
    private lateinit var etDelay: EditText
    private lateinit var etRing: EditText
    private lateinit var etGreeting: EditText
    private lateinit var etGreetLang: EditText
    private lateinit var swReply: Switch
    private lateinit var swGroups: Switch
    private lateinit var swCall: Switch
    private lateinit var swRecord: Switch

    private val ui = Handler(Looper.getMainLooper())
    private var ready = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(40))
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply {
            text = "AlhamGPT"
            textSize = 30f
            setTypeface(null, Typeface.BOLD)
        })
        root.note("Free AI auto-reply for WhatsApp (or any chat app) and an AI call assistant.")
        status = TextView(this)
        status.textSize = 15f
        status.setPadding(0, dp(12), 0, dp(8))
        root.addView(status)

        root.header("1. Setup")
        root.button("Grant permissions") { requestPerms() }
        root.button("Turn on notification access") {
            safeStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        root.button("Notification access is greyed out? Tap for help") { showRestrictedHelp() }
        root.button("Allow background running (battery)") { askBattery() }
        btnService = root.button("Start call assistant") { toggleService() }

        root.header("2. AI (free)")
        etKey = root.field(
            "Gemini API key (free at aistudio.google.com/apikey)",
            prefs.apiKey,
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        )
        etModel = root.field("Gemini model", prefs.model)
        etOwner = root.field("Your name", prefs.ownerName)
        etPersona = root.field("How should the AI behave?", prefs.persona, multiline = true)

        root.header("3. Chat auto-reply")
        swReply = root.toggle("Auto-reply to messages", prefs.autoReply)
        etPackages = root.field(
            "Apps to answer (package names, comma separated)\nWhatsApp = com.whatsapp, WhatsApp Business = com.whatsapp.w4b, Telegram = org.telegram.messenger",
            prefs.packages
        )
        etPrefix = root.field("Text added before each reply (can be empty)", prefs.replyPrefix)
        etDelay = root.field("Seconds to wait before replying", prefs.replyDelaySec.toString(), number = true)
        swGroups = root.toggle("Also reply in group chats", prefs.replyGroups)

        root.header("4. Calls")
        swCall = root.toggle("Auto-answer calls with AI", prefs.callAnswer)
        etRing = root.field("Seconds to ring before answering", prefs.ringDelaySec.toString(), number = true)
        swRecord = root.toggle("Record calls and save a transcript", prefs.recordCalls)
        etGreeting = root.field("What the AI says first", prefs.greeting, multiline = true)
        etGreetLang = root.field("Greeting language code (en-IN, hi-IN, ur-PK, ar-SA ...)", prefs.greetingLang)

        root.header("5. Tools")
        root.button("Save settings") {
            saveAll()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }
        root.button("Test the AI connection") { testAi() }
        root.button("Call recordings") {
            saveAll()
            startActivity(Intent(this, RecordingsActivity::class.java))
        }
        root.button("View activity log") { showLog() }

        ready = true
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        if (ready) saveAll()
        super.onPause()
    }

    // ------------------------------------------------------------------ helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun LinearLayout.header(t: String) {
        val tv = TextView(this@MainActivity)
        tv.text = t
        tv.textSize = 19f
        tv.setTypeface(null, Typeface.BOLD)
        tv.setPadding(0, dp(22), 0, dp(6))
        addView(tv)
    }

    private fun LinearLayout.note(t: String) {
        val tv = TextView(this@MainActivity)
        tv.text = t
        tv.textSize = 14f
        addView(tv)
    }

    private fun LinearLayout.field(
        hint: String,
        value: String,
        type: Int = InputType.TYPE_CLASS_TEXT,
        multiline: Boolean = false,
        number: Boolean = false
    ): EditText {
        val label = TextView(this@MainActivity)
        label.text = hint
        label.textSize = 13f
        label.setPadding(0, dp(8), 0, 0)
        addView(label)
        val e = EditText(this@MainActivity)
        e.setText(value)
        e.inputType = when {
            number -> InputType.TYPE_CLASS_NUMBER
            multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            else -> type
        }
        if (multiline) {
            e.minLines = 3
            e.gravity = Gravity.TOP
        }
        addView(e, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        return e
    }

    private fun LinearLayout.button(t: String, onClick: () -> Unit): Button {
        val b = Button(this@MainActivity)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        addView(b, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        return b
    }

    private fun LinearLayout.toggle(t: String, on: Boolean): Switch {
        val s = Switch(this@MainActivity)
        s.text = t
        s.isChecked = on
        s.setPadding(0, dp(10), 0, dp(10))
        addView(s, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        return s
    }

    private fun safeStart(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open that screen: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveAll() {
        prefs.apiKey = etKey.text.toString().trim()
        prefs.model = etModel.text.toString().trim().ifEmpty { "gemini-2.5-flash" }
        prefs.ownerName = etOwner.text.toString().trim()
        prefs.persona = etPersona.text.toString().trim()
        prefs.autoReply = swReply.isChecked
        prefs.packages = etPackages.text.toString().trim()
        prefs.replyPrefix = etPrefix.text.toString()
        prefs.replyDelaySec = etDelay.text.toString().toIntOrNull()?.coerceIn(0, 60) ?: 2
        prefs.replyGroups = swGroups.isChecked
        prefs.callAnswer = swCall.isChecked
        prefs.ringDelaySec = etRing.text.toString().toIntOrNull()?.coerceIn(1, 60) ?: 10
        prefs.recordCalls = swRecord.isChecked
        prefs.greeting = etGreeting.text.toString().trim()
        prefs.greetingLang = etGreetLang.text.toString().trim().ifEmpty { "en-IN" }
    }

    // ------------------------------------------------------------------ status

    private fun hasPerms(): Boolean {
        val needed = ArrayList<String>()
        needed.add(Manifest.permission.RECORD_AUDIO)
        needed.add(Manifest.permission.READ_PHONE_STATE)
        needed.add(Manifest.permission.ANSWER_PHONE_CALLS)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        return needed.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    }

    private fun hasNotificationAccess(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(packageName)
    }

    private fun batteryOk(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun refresh() {
        fun mark(ok: Boolean) = if (ok) "✅" else "❌"
        status.text = listOf(
            mark(hasPerms()) + " Permissions (microphone, phone, notifications)",
            mark(hasNotificationAccess()) + " Notification access (needed for chat auto-reply)",
            mark(batteryOk()) + " Background running allowed",
            mark(CallService.running) + " Call assistant running"
        ).joinToString("\n")
        btnService.text = if (CallService.running) "Stop call assistant" else "Start call assistant"
    }

    // ------------------------------------------------------------------ actions

    private fun requestPerms() {
        val list = ArrayList<String>()
        list.add(Manifest.permission.RECORD_AUDIO)
        list.add(Manifest.permission.READ_PHONE_STATE)
        list.add(Manifest.permission.ANSWER_PHONE_CALLS)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(list.toTypedArray(), 100)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun askBattery() {
        val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
        i.data = Uri.parse("package:$packageName")
        safeStart(i)
    }

    private fun toggleService() {
        val i = Intent(this, CallService::class.java)
        if (CallService.running) {
            stopService(i)
            ui.postDelayed({ refresh() }, 500)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Tap \"Grant permissions\" first", Toast.LENGTH_LONG).show()
            return
        }
        saveAll()
        try {
            startForegroundService(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start: ${e.message}", Toast.LENGTH_LONG).show()
        }
        ui.postDelayed({ refresh() }, 800)
    }

    private fun showRestrictedHelp() {
        AlertDialog.Builder(this)
            .setTitle("Notification access greyed out?")
            .setMessage(
                "Android blocks some settings for apps installed outside the Play Store.\n\n" +
                    "1. Tap \"Open App info\" below.\n" +
                    "2. Tap the three dots (top right).\n" +
                    "3. Tap \"Allow restricted settings\" and confirm.\n" +
                    "4. Come back and tap \"Turn on notification access\", then switch AlhamGPT on."
            )
            .setPositiveButton("Open App info") { _, _ ->
                val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                i.data = Uri.parse("package:$packageName")
                safeStart(i)
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun testAi() {
        saveAll()
        Toast.makeText(this, "Testing...", Toast.LENGTH_SHORT).show()
        Thread {
            val msg = try {
                val reply = Gemini.chat(
                    prefs, "You are a connection test.", emptyList(),
                    "Say hello in one short sentence."
                )
                "It works!\n\n$reply"
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
            runOnUiThread {
                AlertDialog.Builder(this)
                    .setTitle("AI test")
                    .setMessage(msg)
                    .setPositiveButton("OK", null)
                    .show()
            }
        }.start()
    }

    private fun showLog() {
        AlertDialog.Builder(this)
            .setTitle("Activity log")
            .setMessage(AppLog.read(this))
            .setPositiveButton("OK", null)
            .show()
    }
}
