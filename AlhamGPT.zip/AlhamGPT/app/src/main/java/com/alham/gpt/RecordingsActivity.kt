package com.alham.gpt

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** Lists the saved call recordings: play, share, read transcript, delete. */
class RecordingsActivity : Activity() {

    private var player: MediaPlayer? = null
    private var files: List<File> = emptyList()
    private lateinit var list: ListView
    private lateinit var empty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Call recordings"
            textSize = 24f
        })
        empty = TextView(this).apply {
            text = "No recordings yet."
            setPadding(0, pad, 0, 0)
        }
        root.addView(empty)
        list = ListView(this)
        root.addView(
            list,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setContentView(root)

        list.setOnItemClickListener { _, _, position, _ ->
            if (position in files.indices) showActions(files[position])
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        stopPlayback()
        super.onPause()
    }

    private fun refresh() {
        files = (Storage.dir(this).listFiles { f -> f.isFile && f.name.endsWith(".wav") }?.toList() ?: emptyList())
            .sortedByDescending { it.lastModified() }
        val names = files.map { it.name.removeSuffix(".wav") + "   (" + (it.length() / 1024) + " KB)" }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        empty.text = if (files.isEmpty()) "No recordings yet." else "Tap a recording for options."
    }

    private fun showActions(f: File) {
        val items = arrayOf("Play", "Stop", "Share audio", "Show transcript", "Delete")
        AlertDialog.Builder(this)
            .setTitle(f.name)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> play(f)
                    1 -> stopPlayback()
                    2 -> share(f)
                    3 -> showTranscript(f)
                    4 -> confirmDelete(f)
                }
            }
            .show()
    }

    private fun play(f: File) {
        stopPlayback()
        try {
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            mp.setOnCompletionListener { stopPlayback() }
            mp.start()
            player = mp
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot play: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopPlayback() {
        try {
            player?.stop()
        } catch (e: Exception) { }
        try {
            player?.release()
        } catch (e: Exception) { }
        player = null
    }

    private fun share(f: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val send = Intent(Intent.ACTION_SEND)
            send.type = "audio/wav"
            send.putExtra(Intent.EXTRA_STREAM, uri)
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, "Share recording"))
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot share: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showTranscript(f: File) {
        val t = File(f.parentFile, f.name.removeSuffix(".wav") + ".txt")
        val body = if (t.exists()) t.readText() else "No transcript was saved for this call."
        AlertDialog.Builder(this)
            .setTitle("Transcript")
            .setMessage(body)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun confirmDelete(f: File) {
        AlertDialog.Builder(this)
            .setTitle("Delete this recording?")
            .setPositiveButton("Delete") { _, _ ->
                stopPlayback()
                f.delete()
                File(f.parentFile, f.name.removeSuffix(".wav") + ".txt").delete()
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
