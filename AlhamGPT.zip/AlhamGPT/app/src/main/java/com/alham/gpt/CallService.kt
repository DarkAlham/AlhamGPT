package com.alham.gpt

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

/**
 * Foreground service that watches the phone state. When a call rings it waits the
 * configured number of seconds, answers it, and hands the call to [CallBot].
 */
class CallService : Service() {

    companion object {
        const val CHANNEL = "alham_service"
        @Volatile
        var running = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private val answerRunnable = Runnable { answerCall() }
    private var tm: TelephonyManager? = null
    private var callback: Any? = null
    private var bot: CallBot? = null
    private var weAnswered = false
    private var lastState = TelephonyManager.CALL_STATE_IDLE

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            createChannel()
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(1, notification)
            }
            running = true
            registerCallState()
            AppLog.add(this, "Call assistant started")
        } catch (e: Exception) {
            AppLog.add(this, "Could not start call assistant: ${e.message}")
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "AlhamGPT assistant", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("AlhamGPT is active")
            .setContentText("Call assistant is running")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun registerCallState() {
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            AppLog.add(this, "Phone permission missing - calls will not be detected")
            return
        }
        val t = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        tm = t
        if (Build.VERSION.SDK_INT >= 31) {
            val c = Api31Callback()
            t.registerTelephonyCallback(mainExecutor, c)
            callback = c
        } else {
            @Suppress("DEPRECATION")
            val l = object : PhoneStateListener() {
                @Deprecated("Deprecated in Java")
                override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                    onState(state)
                }
            }
            @Suppress("DEPRECATION")
            t.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
            callback = l
        }
    }

    private inner class Api31Callback : TelephonyCallback(), TelephonyCallback.CallStateListener {
        override fun onCallStateChanged(state: Int) {
            onState(state)
        }
    }

    private fun onState(state: Int) {
        if (state == lastState) return
        lastState = state
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> {
                val prefs = Prefs(this)
                if (prefs.callAnswer && !weAnswered) {
                    AppLog.add(this, "Incoming call - answering in ${prefs.ringDelaySec}s")
                    handler.postDelayed(answerRunnable, prefs.ringDelaySec * 1000L)
                }
            }
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                if (weAnswered && bot == null) {
                    bot = CallBot(this, Prefs(this)).also { it.start() }
                }
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                handler.removeCallbacks(answerRunnable)
                bot?.stop()
                bot = null
                weAnswered = false
            }
        }
    }

    private fun answerCall() {
        if (lastState != TelephonyManager.CALL_STATE_RINGING) return
        if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            AppLog.add(this, "Answer-calls permission missing")
            return
        }
        try {
            val tc = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            weAnswered = true
            @Suppress("DEPRECATION")
            tc.acceptRingingCall()
        } catch (e: Exception) {
            weAnswered = false
            AppLog.add(this, "Could not answer call: ${e.message}")
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(answerRunnable)
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                (callback as? TelephonyCallback)?.let { tm?.unregisterTelephonyCallback(it) }
            } else {
                @Suppress("DEPRECATION")
                tm?.listen(callback as? PhoneStateListener, PhoneStateListener.LISTEN_NONE)
            }
        } catch (e: Exception) {
            AppLog.add(this, "Unregister error: ${e.message}")
        }
        bot?.stop()
        bot = null
        AppLog.add(this, "Call assistant stopped")
        super.onDestroy()
    }
}
