package com.alham.gpt

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.Executors

/**
 * Watches notifications of the chosen apps (WhatsApp by default) and answers
 * incoming messages through the notification's built-in "Reply" action.
 */
class AutoReplyService : NotificationListenerService() {

    private val worker = Executors.newSingleThreadExecutor()
    private val histories = HashMap<String, ArrayList<Pair<String, String>>>()
    private val recent = ArrayList<String>()
    private val seen = HashMap<String, Long>()

    override fun onListenerConnected() {
        AppLog.add(this, "Auto-reply listener connected")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            handle(sbn)
        } catch (e: Exception) {
            AppLog.add(this, "Notification error: ${e.message}")
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        val prefs = Prefs(this)
        if (!prefs.autoReply) return
        if (sbn.packageName == packageName) return

        val allowed = prefs.packages.split(",", "\n", " ").map { it.trim() }.filter { it.isNotEmpty() }
        if (sbn.packageName !in allowed) return

        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras ?: return

        val isGroup = ex.getBoolean("android.isGroupConversation", false)
        if (isGroup && !prefs.replyGroups) return

        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (lastMessageText(ex) ?: ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()).orEmpty().trim()
        if (title.isEmpty() || text.isEmpty()) return
        if (title.equals("WhatsApp", ignoreCase = true)) return
        if (Regex("^\\d+ (new )?messages?.*$", RegexOption.IGNORE_CASE).matches(text)) return

        // Ignore the echo of our own replies.
        val isEcho = synchronized(recent) { recent.any { it.isNotEmpty() && text.contains(it.take(40)) } }
        if (isEcho) return

        val action = findReplyAction(n) ?: return

        // Ignore duplicate updates of the same notification.
        val now = System.currentTimeMillis()
        val sig = sbn.key + "|" + text
        synchronized(seen) {
            val last = seen[sig]
            if (last != null && now - last < 60_000) return
            seen[sig] = now
            if (seen.size > 200) {
                val it = seen.entries.iterator()
                while (it.hasNext()) if (now - it.next().value > 300_000) it.remove()
            }
        }

        val key = sbn.packageName + "|" + title
        AppLog.add(this, "Message from \"$title\": ${text.take(60)}")

        worker.execute {
            try {
                val hist = synchronized(histories) { (histories[key] ?: ArrayList()).toList() }
                val system = Gemini.system(prefs, false) + " The person messaging is named \"$title\"."
                val reply = Gemini.chat(prefs, system, hist, text).trim()
                if (reply.isEmpty()) return@execute

                synchronized(recent) {
                    recent.add(reply)
                    while (recent.size > 20) recent.removeAt(0)
                }
                if (prefs.replyDelaySec > 0) Thread.sleep(prefs.replyDelaySec * 1000L)
                sendReply(action, prefs.replyPrefix + reply)

                synchronized(histories) {
                    val h = histories.getOrPut(key) { ArrayList() }
                    h.add("user" to text)
                    h.add("model" to reply)
                    while (h.size > 12) h.removeAt(0)
                }
                AppLog.add(this@AutoReplyService, "Replied to \"$title\": ${reply.take(60)}")
            } catch (e: Exception) {
                AppLog.add(this@AutoReplyService, "Reply failed: ${e.message}")
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun lastMessageText(ex: Bundle): String? {
        val msgs = ex.getParcelableArray("android.messages") ?: return null
        val last = msgs.lastOrNull() as? Bundle ?: return null
        return last.getCharSequence("text")?.toString()
    }

    @Suppress("DEPRECATION")
    private fun findReplyAction(n: Notification): Notification.Action? {
        val acts = n.actions
        if (acts != null) {
            for (a in acts) {
                val inputs = a.remoteInputs
                if (inputs != null && inputs.isNotEmpty()) return a
            }
        }
        val wear = n.extras?.getBundle("android.wearable.EXTENSIONS")
        val list = wear?.getParcelableArrayList<Notification.Action>("actions")
        if (list != null) {
            for (a in list) {
                val inputs = a.remoteInputs
                if (inputs != null && inputs.isNotEmpty()) return a
            }
        }
        return null
    }

    private fun sendReply(action: Notification.Action, text: String) {
        val inputs = action.remoteInputs ?: return
        val intent = Intent()
        val results = Bundle()
        for (ri in inputs) results.putCharSequence(ri.resultKey, text)
        RemoteInput.addResultsToIntent(inputs, intent, results)
        action.actionIntent.send(this, 0, intent)
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }
}
