package com.alham.gpt

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Talks to the caller after the call has been answered:
 *  - records the whole call to a WAV file (microphone + speaker),
 *  - detects when the caller stops speaking,
 *  - sends that speech to Gemini, speaks the reply with text-to-speech,
 *  - saves a text transcript next to the recording.
 *
 * Android does not give normal apps direct access to call audio, so the phone is put on
 * speaker and the microphone/speaker are used. Results depend on the phone model.
 */
class CallBot(private val ctx: Context, private val prefs: Prefs) {

    private val sampleRate = 16000
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val history = ArrayList<Pair<String, String>>()
    private val transcript = StringBuilder()

    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var running = false
    @Volatile private var busy = false
    @Volatile private var quietUntil = 0L

    private var recorder: AudioRecord? = null
    private var recThread: Thread? = null
    private var wav: RandomAccessFile? = null
    private var wavFile: File? = null
    private var pcmBytes = 0L
    private var baseName = ""

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            busy = true
        }

        override fun onDone(utteranceId: String?) {
            finishSpeaking()
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            finishSpeaking()
        }

        override fun onError(utteranceId: String?, errorCode: Int) {
            finishSpeaking()
        }
    }

    private fun finishSpeaking() {
        quietUntil = SystemClock.elapsedRealtime() + 600
        busy = false
    }

    fun start() {
        if (running) return
        running = true
        busy = true // stays busy while the greeting is spoken
        baseName = "call_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        AppLog.add(ctx, "Call answered - assistant talking")
        routeToSpeaker()
        startRecording()
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS && running) {
                ttsReady = true
                val t = tts
                t?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                t?.setOnUtteranceProgressListener(listener)
                log("AlhamGPT", prefs.greeting)
                speak(prefs.greeting, prefs.greetingLang)
            } else {
                AppLog.add(ctx, "Text-to-speech not available (status $status)")
                busy = false
            }
        }
    }

    fun stop() {
        if (!running) return
        running = false
        try { recThread?.join(1500) } catch (e: Exception) { }
        try { recorder?.stop() } catch (e: Exception) { }
        try { recorder?.release() } catch (e: Exception) { }
        recorder = null
        closeWav()
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) { }
        tts = null
        worker.shutdownNow()
        saveTranscript()
        restoreAudio()
        AppLog.add(ctx, "Call ended - saved as $baseName")
    }

    // ---------------------------------------------------------------- audio routing

    private fun routeToSpeaker() {
        try {
            @Suppress("DEPRECATION")
            audio.isSpeakerphoneOn = true
            if (Build.VERSION.SDK_INT >= 31) {
                val speaker = audio.availableCommunicationDevices
                    .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                if (speaker != null) audio.setCommunicationDevice(speaker)
            }
        } catch (e: Exception) {
            AppLog.add(ctx, "Speaker routing failed: ${e.message}")
        }
    }

    private fun restoreAudio() {
        try {
            @Suppress("DEPRECATION")
            audio.isSpeakerphoneOn = false
            if (Build.VERSION.SDK_INT >= 31) audio.clearCommunicationDevice()
        } catch (e: Exception) { }
    }

    // ---------------------------------------------------------------- speaking

    private fun speak(text: String, lang: String?) {
        val t = tts
        if (t == null || !ttsReady || text.isBlank()) {
            busy = false
            return
        }
        busy = true
        try {
            val locale = if (lang.isNullOrBlank()) Locale.getDefault() else Locale.forLanguageTag(lang)
            val r = t.setLanguage(locale)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                t.setLanguage(Locale.getDefault())
            }
        } catch (e: Exception) { }
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    // ---------------------------------------------------------------- recording + listening

    private fun startRecording() {
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) {
            AppLog.add(ctx, "Microphone not available")
            return
        }
        val rec: AudioRecord = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuf * 4
            )
        } catch (e: Exception) {
            AppLog.add(ctx, "Could not open microphone: ${e.message}")
            return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            AppLog.add(ctx, "Microphone is busy or blocked")
            return
        }
        recorder = rec
        openWav()
        try {
            rec.startRecording()
        } catch (e: Exception) {
            AppLog.add(ctx, "Microphone start failed: ${e.message}")
            return
        }
        recThread = Thread { listenLoop(rec) }.also { it.start() }
    }

    private fun listenLoop(rec: AudioRecord) {
        val frame = ShortArray(sampleRate / 50) // 20 ms
        val pre = ArrayList<ShortArray>()
        val utter = ByteArrayOutputStream()
        var inSpeech = false
        var speechStart = 0L
        var lastVoice = 0L
        var voicedMs = 0
        var noise = 300.0

        while (running) {
            val n = rec.read(frame, 0, frame.size)
            if (n < 0) break
            if (n == 0) continue
            writePcm(frame, n)

            val now = SystemClock.elapsedRealtime()
            if (busy || now < quietUntil) {
                // Do not listen while we are speaking or thinking.
                inSpeech = false
                utter.reset()
                pre.clear()
                continue
            }

            var sum = 0.0
            for (k in 0 until n) sum += frame[k].toDouble() * frame[k].toDouble()
            val rms = Math.sqrt(sum / n)
            val voiced = rms > Math.max(700.0, noise * 3.0)
            if (!voiced) noise = noise * 0.95 + rms * 0.05

            if (voiced) {
                if (!inSpeech) {
                    inSpeech = true
                    utter.reset()
                    for (p in pre) utter.write(toBytes(p, p.size))
                    pre.clear()
                    speechStart = now
                    voicedMs = 0
                }
                utter.write(toBytes(frame, n))
                voicedMs += 20
                lastVoice = now
            } else if (inSpeech) {
                utter.write(toBytes(frame, n))
            } else {
                pre.add(frame.copyOf(n))
                if (pre.size > 15) pre.removeAt(0)
            }

            if (inSpeech && (now - lastVoice > 900 || now - speechStart > 15000)) {
                inSpeech = false
                if (voicedMs >= 400) {
                    val pcm = utter.toByteArray()
                    busy = true
                    try {
                        worker.execute { handleSpeech(pcm) }
                    } catch (e: Exception) {
                        busy = false
                    }
                }
                utter.reset()
            }
        }
    }

    private fun handleSpeech(pcm: ByteArray) {
        try {
            val wavBytes = wavHeader(pcm.size) + pcm
            val hist = synchronized(history) { history.toList() }
            val res = Gemini.voiceTurn(prefs, Gemini.system(prefs, true), hist, wavBytes)
            if (!running) return
            if (res.transcript.isBlank() || res.reply.isBlank()) {
                busy = false
                return
            }
            synchronized(history) {
                history.add("user" to res.transcript)
                history.add("model" to res.reply)
                while (history.size > 16) history.removeAt(0)
            }
            log("Caller", res.transcript)
            log("AlhamGPT", res.reply)
            speak(res.reply, res.lang)
        } catch (e: Exception) {
            AppLog.add(ctx, "Call AI error: ${e.message}")
            if (running) speak("Sorry, I am having trouble. Please try again.", "en-IN") else busy = false
        }
    }

    // ---------------------------------------------------------------- files

    private fun openWav() {
        if (!prefs.recordCalls) return
        try {
            val f = File(Storage.dir(ctx), "$baseName.wav")
            val r = RandomAccessFile(f, "rw")
            r.write(ByteArray(44))
            wav = r
            wavFile = f
        } catch (e: Exception) {
            AppLog.add(ctx, "Could not create recording file: ${e.message}")
        }
    }

    private fun writePcm(frame: ShortArray, n: Int) {
        val r = wav ?: return
        try {
            val bytes = toBytes(frame, n)
            r.write(bytes)
            pcmBytes += bytes.size
        } catch (e: Exception) { }
    }

    private fun closeWav() {
        val r = wav ?: return
        try {
            r.seek(0)
            r.write(wavHeader(pcmBytes.toInt()))
            r.close()
        } catch (e: Exception) { }
        wav = null
        val f = wavFile
        if (f != null && pcmBytes < 32000L) f.delete() // shorter than 1 second: discard
    }

    private fun saveTranscript() {
        if (!prefs.recordCalls || transcript.isEmpty()) return
        try {
            File(Storage.dir(ctx), "$baseName.txt").writeText(transcript.toString())
        } catch (e: Exception) { }
    }

    private fun log(who: String, text: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        transcript.append("[").append(stamp).append("] ").append(who).append(": ").append(text).append("\n")
    }

    private fun toBytes(frame: ShortArray, n: Int): ByteArray {
        val out = ByteArray(n * 2)
        for (k in 0 until n) {
            val v = frame[k].toInt()
            out[2 * k] = (v and 0xFF).toByte()
            out[2 * k + 1] = ((v shr 8) and 0xFF).toByte()
        }
        return out
    }

    private fun wavHeader(dataLen: Int): ByteArray {
        val b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray(Charsets.US_ASCII))
        b.putInt(36 + dataLen)
        b.put("WAVE".toByteArray(Charsets.US_ASCII))
        b.put("fmt ".toByteArray(Charsets.US_ASCII))
        b.putInt(16)
        b.putShort(1.toShort())
        b.putShort(1.toShort())
        b.putInt(sampleRate)
        b.putInt(sampleRate * 2)
        b.putShort(2.toShort())
        b.putShort(16.toShort())
        b.put("data".toByteArray(Charsets.US_ASCII))
        b.putInt(dataLen)
        return b.array()
    }
}
