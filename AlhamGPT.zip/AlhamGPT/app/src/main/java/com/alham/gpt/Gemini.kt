package com.alham.gpt

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Minimal client for the free Google Gemini API (no extra libraries needed). */
object Gemini {

    class VoiceResult(val transcript: String, val lang: String, val reply: String)

    fun system(p: Prefs, voice: Boolean): String {
        val who = p.ownerName.ifBlank { "the owner" }
        val where = if (voice) "phone calls" else "chat messages"
        val style = if (voice) {
            "You are speaking aloud, so use at most two short natural sentences, with no emojis, lists or markdown."
        } else {
            "Keep replies short (1-3 sentences) and natural for a chat."
        }
        return "You are AlhamGPT, an AI assistant that answers $who's $where while $who is unavailable. " +
            "You are an AI: say so honestly if asked, and never pretend to be human or to be $who. " +
            "Never share passwords, OTPs, bank or card details, and never agree to payments or promises on behalf of $who; " +
            "offer to take a message instead. " +
            "Reply in the same language and script the other person uses. $style " + p.persona
    }

    /** Text chat. history = list of (role, text) where role is "user" or "model". */
    fun chat(p: Prefs, system: String, history: List<Pair<String, String>>, userText: String): String {
        val contents = JSONArray()
        for ((role, text) in history) contents.put(textContent(role, text))
        contents.put(textContent("user", userText))
        val resp = post(p, baseBody(system, contents))
        return extractText(resp).trim()
    }

    /** One spoken turn: sends the caller's audio, gets transcript + language + reply. */
    fun voiceTurn(p: Prefs, system: String, history: List<Pair<String, String>>, wav: ByteArray): VoiceResult {
        val contents = JSONArray()
        for ((role, text) in history) contents.put(textContent(role, text))

        val instruction = "The caller's latest speech is in the attached audio. " +
            "Return JSON with: transcript (what the caller said), lang (BCP-47 code of the caller's language, " +
            "for example en-IN, hi-IN, ur-PK, ar-SA), and reply (your short spoken answer in that same language). " +
            "If the audio is only silence or noise, return an empty transcript and an empty reply."
        val parts = JSONArray()
        parts.put(JSONObject().put("text", instruction))
        parts.put(
            JSONObject().put(
                "inline_data",
                JSONObject()
                    .put("mime_type", "audio/wav")
                    .put("data", Base64.encodeToString(wav, Base64.NO_WRAP))
            )
        )
        contents.put(JSONObject().put("role", "user").put("parts", parts))

        val body = baseBody(system, contents)
        val props = JSONObject()
            .put("transcript", JSONObject().put("type", "STRING"))
            .put("lang", JSONObject().put("type", "STRING"))
            .put("reply", JSONObject().put("type", "STRING"))
        val schema = JSONObject()
            .put("type", "OBJECT")
            .put("properties", props)
            .put("required", JSONArray().put("transcript").put("lang").put("reply"))
        val gc = body.getJSONObject("generationConfig")
        gc.put("responseMimeType", "application/json")
        gc.put("responseSchema", schema)

        val raw = extractText(post(p, body)).trim()
        return try {
            val j = JSONObject(raw)
            VoiceResult(j.optString("transcript", ""), j.optString("lang", ""), j.optString("reply", ""))
        } catch (e: Exception) {
            VoiceResult("(speech)", "", raw)
        }
    }

    private fun textContent(role: String, text: String): JSONObject =
        JSONObject().put("role", role)
            .put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun baseBody(system: String, contents: JSONArray): JSONObject {
        val body = JSONObject()
        body.put(
            "systemInstruction",
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
        )
        body.put("contents", contents)
        body.put(
            "generationConfig",
            JSONObject().put("maxOutputTokens", 2048).put("temperature", 0.7)
        )
        return body
    }

    private fun post(p: Prefs, body: JSONObject): String {
        val key = p.apiKey.trim()
        if (key.isEmpty()) throw IOException("Add your free Gemini API key in AlhamGPT first")
        val model = p.model.trim().removePrefix("models/").ifEmpty { "gemini-2.5-flash" }
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 45000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("Gemini error $code: " + errorMessage(text))
            return text
        } finally {
            c.disconnect()
        }
    }

    private fun errorMessage(text: String): String {
        return try {
            JSONObject(text).getJSONObject("error").getString("message")
        } catch (e: Exception) {
            text.take(200)
        }
    }

    private fun extractText(resp: String): String {
        val j = JSONObject(resp)
        val cands = j.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val block = j.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            throw IOException("No reply from Gemini" + if (block.isNotEmpty()) " (blocked: $block)" else "")
        }
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (n in 0 until parts.length()) {
                val part = parts.getJSONObject(n)
                if (part.optBoolean("thought", false)) continue
                sb.append(part.optString("text", ""))
            }
        }
        return sb.toString()
    }
}
