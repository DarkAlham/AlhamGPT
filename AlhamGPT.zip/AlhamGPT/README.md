# AlhamGPT

Free Android app: AI auto-reply for WhatsApp (or any chat app by package name),
AI call answering, call recording + transcripts. No paid services.

- Chat AI: Google Gemini free tier (your own free API key)
- No ads, no server, everything runs on your phone
- Android 8.0+ (API 26)

---

## 1. Get the free AI key (2 minutes)

1. Open https://aistudio.google.com/apikey on your phone
2. Sign in with Google, tap **Create API key**, copy it
3. You will paste it into AlhamGPT later. It costs nothing.

## 2. Build the APK (pick ONE way)

### Way A: Phone only, using GitHub (free)

1. Create a free account at https://github.com
2. Create a new **private** repository (name: `AlhamGPT`)
3. In the repository: **Add file > Upload files** and upload `AlhamGPT.zip`
   (the zip itself, do not unzip it). Commit.
4. **Add file > Create new file**. In the name box type
   `.github/workflows/build.yml` and paste the contents of `build.yml`. Commit.
5. Open the **Actions** tab. Wait about 4 to 6 minutes for the green tick.
6. Open the finished run, scroll to **Artifacts**, download `AlhamGPT-apk`,
   unzip it and you have `AlhamGPT.apk`.

If the run shows a red cross, open it, copy the red error text and send it to me.

### Way B: Computer with Android Studio (free)

1. Install Android Studio, then **File > Open** and choose the `AlhamGPT` folder.
2. Wait for Gradle sync, then **Build > Build APK(s)**.
3. The file is in `app/build/outputs/apk/debug/app-debug.apk`.

## 3. Install

1. Copy the APK to the phone, tap it, allow "Install unknown apps" for your file manager or browser.
2. Open **AlhamGPT**.

## 4. First-time setup inside the app (in this order)

1. **Grant permissions** > allow Microphone, Phone, Calls, Notifications.
2. **Notification access is greyed out?** Android blocks this for apps installed from
   a file. Fix: App info > three dots (top right) > **Allow restricted settings**.
   Then tap **Turn on notification access** and switch AlhamGPT ON.
3. **Allow background running (battery)** > Allow.
   On Xiaomi, Oppo, Vivo, Realme, Samsung also set the app to
   "No restrictions" / "Autostart: on" in the phone's own battery settings.
4. Paste your **Gemini API key**, fill your name, tap **Save settings**.
5. Tap **Test the AI connection**. You must see "It works!".
6. Tap **Start call assistant** (only needed for calls).

WhatsApp auto-reply works as soon as notification access is on and the key is saved.
Reply works on the normal notification; the message must show a **Reply** button.
Do not mute the chat and do not turn off WhatsApp notifications.

## 5. Custom apps

In "Apps to answer", add more package names separated by commas, for example:

- WhatsApp: `com.whatsapp`
- WhatsApp Business: `com.whatsapp.w4b`
- Telegram: `org.telegram.messenger`
- Messenger: `com.facebook.orca`
- Instagram: `com.instagram.android`

Any app whose notification has a Reply button will work.

## 6. Calls: what works and what does not (please read)

- Auto-answer: AlhamGPT answers an incoming call after N seconds using Android's
  official "answer phone calls" permission.
- Talking: Android does not allow normal apps to send audio into a phone call.
  AlhamGPT therefore turns on the speaker, speaks with text-to-speech and listens
  with the microphone. This works on some phones and is silent on others
  (many Android 10+ phones block the microphone during calls). Test with a friend first.
- Recording: saved in **Call recordings** inside the app (play, share, read the transcript).
  If your phone blocks the microphone during calls, the file will be silent.
- After a phone restart, open AlhamGPT and tap **Start call assistant** again
  (Android does not allow it to start microphone services by itself at boot).
  WhatsApp auto-reply restarts on its own.
- Dual SIM, call waiting and some phone brands may behave differently.

## 7. Privacy and law

- Your messages and call audio are sent to Google Gemini to produce replies.
  On the free tier Google may use this data to improve its products. Do not use it for
  confidential conversations.
- The AI always introduces itself as an AI assistant and says the call may be recorded.
  Keep that greeting. In many countries you must tell people before recording a call.
- Never give the AI sensitive powers (payments, OTPs). The built-in instructions tell it
  not to share those, but you remain responsible for what it says in your name.

## 8. Troubleshooting

| Problem | Fix |
|---|---|
| No reply on WhatsApp | Status screen must show notification access ticked; message must have a Reply button; check **View activity log** |
| "Gemini error 400/403" | Wrong or missing API key |
| "Gemini error 404" | Model name wrong; use `gemini-2.5-flash` or `gemini-2.5-flash-lite` |
| "Gemini error 429" | Free limit reached, wait a minute |
| Replies stop after some hours | Battery setting: set AlhamGPT to "No restrictions" |
| Call not answered | Turn on "Auto-answer calls", tap Start call assistant, grant Phone permission |
| Caller cannot hear / AI cannot hear | Phone blocks call audio, see section 6 |

## Project layout

```
app/src/main/java/com/alham/gpt/
  MainActivity.kt        settings screen
  AutoReplyService.kt    reads notifications, sends replies
  CallService.kt         answers calls
  CallBot.kt             listens, talks, records
  Gemini.kt              free Gemini API client
  RecordingsActivity.kt  recordings list
  Prefs.kt               settings, log, storage
```
